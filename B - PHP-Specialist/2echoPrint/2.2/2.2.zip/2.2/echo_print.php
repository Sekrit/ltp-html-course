<?php
    echo("<h1>Echoing out a heading</h1>");
    print("<h1>Printing a heading</h1>");
    
    echo "Old school style echo...";
    print "<br/>Old school style print...";

    print("<br/>");

    //Expressions
    
    echo(2+3);
    print("<br/>" . 9*5);
?>